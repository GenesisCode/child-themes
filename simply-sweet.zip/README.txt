Simply Sweet Genesis WordPress Theme
http://demo.auxanocreative.com/simply-sweet

INSTALL: 
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and select Appearance.
3. Select Simply Sweet WordPress theme.

CUSTOMIZE HEADER:
If you would like help customizing the header of your site, feel free to contact me anytime. The font used in the site title is Pharmacy which can be downloaded for free here: http://www.dafont.com/search.php?psize=m&q=pharmacy.

FOOTER CREDITS:
You are not required to display the footer credits, but it would be very much appreciated. Thank you!

If you are looking for theme support, please visit http://www.auxanocreative.com/contact.

Susan Nelson
info@auxanocreative.com
http://auxanocreative.com