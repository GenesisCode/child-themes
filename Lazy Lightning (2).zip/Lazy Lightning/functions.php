<?php
//Add typekit to website
function theme_typekit() {
    wp_enqueue_script( 'theme_typekit', '//use.typekit.net/xgy1caz.js');
}
add_action( 'wp_enqueue_scripts', 'theme_typekit' );

function theme_typekit_inline() {
  if ( wp_script_is( 'theme_typekit', 'done' ) ) { ?>
    <script type="text/javascript">try{Typekit.load();}catch(e){}</script>
<?php }
}
add_action( 'wp_head', 'theme_typekit_inline' );

//* Remove the site title
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
//* Remove the site description
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'custom_footer_creds_text' );
function custom_footer_creds_text() {
  echo '<div class="creds"><p>';
  echo '<div class="location"><i class="fontawesome-wrench"></i> Handcrafted in <a href="http://michaelmusgrove.com">Louisville</a> <i class="fontawesome-beaker"></i> <p><i class="fontawesome-heart pulse"></i></p></div>';
  echo '<div class="copyright">Copyright &copy; ';
  echo date('Y');
  echo ' &middot; <a href="http://webdesignpop.com">web design POP</a> ';
  echo '</div></p></div>';
}

//* Customize the return to top of page text
add_filter( 'genesis_footer_backtotop_text', 'custom_footer_backtotop_text' );
function custom_footer_backtotop_text($backtotop) {
  $backtotop = '<p id="backtotop"><a href="#top" ><i class="entypo-circle-arrow-up"></i></a></p>';
  return $backtotop;
}

//* Display a custom favicon
add_filter( 'genesis_pre_load_favicon', 'custom_favicon_filter' );
function custom_favicon_filter( $favicon_url ) {
  return 'http://webdesign.com/wp-content/images/robot-favicon.ico';
}
