=== Solo Child Theme for Genesis Framework ===

Description: Solo is a no-sidebar child theme for Genesis Framework 

Github project link: https://github.com/psahalot/solo


=== Installation Instructions ===

1. Upload the Solo theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Solo theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.


=== Theme Support ===

Please visit http://iampuneet.com/contact for theme support.
